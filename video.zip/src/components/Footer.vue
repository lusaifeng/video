<template>
  <div class="footer">
    @copyright 上海庚易有限公司
  </div>
</template>
<script>
export default {
  name: "VFooter",
  data() {
    return {

    }
  },
  methods: {}
};
</script>

<style>

</style>