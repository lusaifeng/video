'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_URI: `"${process.env.API_URI}"`
}
